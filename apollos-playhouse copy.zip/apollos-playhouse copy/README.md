# Apollo's Playhouse

An open-source, modular show control and spatial audio suite for modern theater productions.

## Features

- 🎭 QLab-style cue management system
- 🎚️ Professional audio routing and effects
- 🌌 3D spatial audio simulation
- 📏 Room measurement and calibration tools
- 🔌 Extensible plugin system
- 🌍 Cross-platform support (macOS, Windows, Linux)

## Getting Started

### Prerequisites

- Rust (latest stable)
- Cargo
- CMake (for some dependencies)
- JUCE (for UI components)

### Building

```bash
# Clone the repository
git clone https://github.com/yourusername/apollos-playhouse.git
cd apollos-playhouse

# Build in release mode
cargo build --release
```

## Architecture

- `core/`: Core audio engine and cue management
- `spatial/`: 3D audio processing and simulation
- `ui/`: Cross-platform user interface
- `plugins/`: Plugin SDK and built-in plugins
- `scripts/`: Example scripts and automation
- `docs/`: Documentation

## License

Licensed under either of:

 * Apache License, Version 2.0
 * MIT license

at your option.
