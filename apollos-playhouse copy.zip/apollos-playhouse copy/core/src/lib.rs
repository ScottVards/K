//! Apollo Core - The audio engine and cue management system for Apollo's Playhouse
//!
//! This crate provides the core functionality for handling audio processing,
//! cue management, and real-time control of theatrical audio systems.

#![warn(missing_docs)]
#![warn(rustdoc::missing_crate_level_docs)]

mod audio;
mod cue;
mod engine;
mod error;
mod time;

pub use audio::*;
pub use cue::*;
pub use engine::*;
pub use error::*;
pub use time::*;

/// Re-export of commonly used items
pub mod prelude {
    pub use crate::{
        audio::{AudioBuffer, AudioDevice, AudioFormat, AudioStream},
        cue::{Cue, CueId, CueList, CueState, CueType},
        engine::{AudioEngine, AudioEngineConfig},
        error::Result,
        time::{BeatTime, SampleTime, TimeBase, TimeSignature},
    };
}
