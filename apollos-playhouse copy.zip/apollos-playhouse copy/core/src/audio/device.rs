//! Audio device abstraction layer

use std::fmt;
use std::sync::Arc;

use crate::audio::format::{AudioDeviceConfig, AudioFormat, Direction, StreamStatus};
use crate::audio::stream::{AudioCallback, AudioStreamHandle};
use crate::error::{Error, Result};
use crate::time::SampleTime;

/// Unique identifier for an audio device
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct DeviceId(pub String);

impl fmt::Display for DeviceId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

/// Information about an audio device
#[derive(Debug, Clone)]
pub struct AudioDeviceInfo {
    /// Device identifier
    pub id: DeviceId,
    /// Human-readable name
    pub name: String,
    /// Supported input formats
    pub input_formats: Vec<AudioFormat>,
    /// Supported output formats
    pub output_formats: Vec<AudioFormat>,
    /// Default configuration
    pub default_config: AudioDeviceConfig,
    /// Whether the device is set as the system default
    pub is_default: bool,
}

/// Audio driver backend enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AudioBackend {
    /// JUCE cross-platform backend
    Juce,
    /// Core Audio (macOS)
    CoreAudio,
    /// ASIO (Windows)
    Asio,
    /// JACK (Linux)
    Jack,
    /// ALSA (Linux)
    Alsa,
    /// WASAPI (Windows)
    Wasapi,
}

/// Trait implemented by audio backend device managers
pub trait AudioDeviceManager: Send + Sync {
    /// Returns the backend type
    fn backend(&self) -> AudioBackend;

    /// Enumerates available devices
    fn enumerate(&self) -> Result<Vec<AudioDeviceInfo>>;

    /// Returns the default input device
    fn default_input(&self) -> Result<AudioDeviceInfo>;

    /// Returns the default output device
    fn default_output(&self) -> Result<AudioDeviceInfo>;

    /// Opens a device stream with the specified configuration
    fn open_stream(
        &self,
        device: &AudioDeviceInfo,
        config: &AudioDeviceConfig,
        direction: Direction,
        callback: Arc<dyn AudioCallback>,
    ) -> Result<AudioStreamHandle>;
}

/// A placeholder implementation used in environments without a native audio backend
pub struct NullAudioDeviceManager;

impl AudioDeviceManager for NullAudioDeviceManager {
    fn backend(&self) -> AudioBackend {
        AudioBackend::Juce
    }

    fn enumerate(&self) -> Result<Vec<AudioDeviceInfo>> {
        Err(Error::AudioDevice("Audio backend not available".into()))
    }

    fn default_input(&self) -> Result<AudioDeviceInfo> {
        Err(Error::AudioDevice("Audio backend not available".into()))
    }

    fn default_output(&self) -> Result<AudioDeviceInfo> {
        Err(Error::AudioDevice("Audio backend not available".into()))
    }

    fn open_stream(
        &self,
        _device: &AudioDeviceInfo,
        _config: &AudioDeviceConfig,
        _direction: Direction,
        _callback: Arc<dyn AudioCallback>,
    ) -> Result<AudioStreamHandle> {
        Err(Error::AudioDevice(
            "Audio backend not available at runtime".into(),
        ))
    }
}

/// Statistics for audio I/O streams
#[derive(Debug, Default, Clone, Copy, PartialEq)]
pub struct StreamMetrics {
    /// Time of the last callback (sample time)
    pub last_callback: Option<SampleTime>,
    /// Total underruns detected
    pub underruns: u64,
    /// Total overruns detected
    pub overruns: u64,
    /// Average callback duration in microseconds
    pub avg_callback_us: f64,
}

/// Trait for observing device events (plug/unplug, XRuns)
pub trait DeviceEventListener: Send + Sync {
    /// Called when the device status changes
    fn on_status_change(&self, _status: StreamStatus) {}

    /// Called when an underrun is detected
    fn on_underrun(&self) {}

    /// Called when an overrun is detected
    fn on_overrun(&self) {}
}
