//! Audio buffer implementation

use std::ops::{Deref, DerefMut};

use crate::error::Result;

/// Trait for audio buffers that can be read from and written to
pub trait AudioBuffer: Send + Sync + 'static {
    /// Returns the number of channels in the buffer
    fn num_channels(&self) -> usize;
    
    /// Returns the number of samples per channel in the buffer
    fn num_samples(&self) -> usize;
    
    /// Returns the sample rate in Hz
    fn sample_rate(&self) -> u32;
    
    /// Returns a reference to the channel data at the given index
    fn channel(&self, channel: usize) -> &[f32];
    
    /// Returns a mutable reference to the channel data at the given index
    fn channel_mut(&mut self, channel: usize) -> &mut [f32];
    
    /// Clears the buffer (sets all samples to 0.0)
    fn clear(&mut self) {
        for ch in 0..self.num_channels() {
            let channel = self.channel_mut(ch);
            for sample in channel.iter_mut() {
                *sample = 0.0;
            }
        }
    }
    
    /// Applies a gain factor to all samples in the buffer
    fn apply_gain(&mut self, gain: f32) {
        for ch in 0..self.num_channels() {
            let channel = self.channel_mut(ch);
            for sample in channel.iter_mut() {
                *sample *= gain;
            }
        }
    }
}

/// A simple interleaved audio buffer
pub struct InterleavedBuffer {
    data: Vec<f32>,
    num_channels: usize,
    sample_rate: u32,
}

impl InterleavedBuffer {
    /// Creates a new interleaved audio buffer
    pub fn new(num_channels: usize, num_samples: usize, sample_rate: u32) -> Self {
        Self {
            data: vec![0.0; num_channels * num_samples],
            num_channels,
            sample_rate,
        }
    }
    
    /// Returns the raw interleaved audio data
    pub fn as_slice(&self) -> &[f32] {
        &self.data
    }
    
    /// Returns the raw interleaved audio data as mutable
    pub fn as_mut_slice(&mut self) -> &mut [f32] {
        &mut self.data
    }
}

impl AudioBuffer for InterleavedBuffer {
    fn num_channels(&self) -> usize {
        self.num_channels
    }
    
    fn num_samples(&self) -> usize {
        self.data.len() / self.num_channels
    }
    
    fn sample_rate(&self) -> u32 {
        self.sample_rate
    }
    
    fn channel(&self, channel: usize) -> &[f32] {
        let samples_per_channel = self.num_samples();
        &self.data[channel * samples_per_channel..(channel + 1) * samples_per_channel]
    }
    
    fn channel_mut(&mut self, channel: usize) -> &mut [f32] {
        let samples_per_channel = self.num_samples();
        &mut self.data[channel * samples_per_channel..(channel + 1) * samples_per_channel]
    }
}

/// A non-interleaved audio buffer
pub struct PlanarBuffer {
    data: Vec<Vec<f32>>,
    sample_rate: u32,
}

impl PlanarBuffer {
    /// Creates a new planar audio buffer
    pub fn new(num_channels: usize, num_samples: usize, sample_rate: u32) -> Self {
        Self {
            data: vec![vec![0.0; num_samples]; num_channels],
            sample_rate,
        }
    }
    
    /// Returns the raw planar audio data
    pub fn as_slice(&self) -> &[Vec<f32>] {
        &self.data
    }
    
    /// Returns the raw planar audio data as mutable
    pub fn as_mut_slice(&mut self) -> &mut [Vec<f32>] {
        &mut self.data
    }
}

impl AudioBuffer for PlanarBuffer {
    fn num_channels(&self) -> usize {
        self.data.len()
    }
    
    fn num_samples(&self) -> usize {
        self.data.first().map_or(0, |ch| ch.len())
    }
    
    fn sample_rate(&self) -> u32 {
        self.sample_rate
    }
    
    fn channel(&self, channel: usize) -> &[f32] {
        &self.data[channel]
    }
    
    fn channel_mut(&mut self, channel: usize) -> &mut [f32] {
        &mut self.data[channel]
    }
}

/// A wrapper that implements `AudioBuffer` for any type that implements `Deref` and `DerefMut`
pub struct BufferRef<'a, T: AudioBuffer + ?Sized> {
    inner: &'a mut T,
}

impl<'a, T: AudioBuffer + ?Sized> BufferRef<'a, T> {
    /// Creates a new buffer reference
    pub fn new(buffer: &'a mut T) -> Self {
        Self { inner: buffer }
    }
    
    /// Consumes the wrapper and returns the inner buffer
    pub fn into_inner(self) -> &'a mut T {
        self.inner
    }
}

impl<'a, T: AudioBuffer + ?Sized> Deref for BufferRef<'a, T> {
    type Target = T;
    
    fn deref(&self) -> &Self::Target {
        self.inner
    }
}

impl<'a, T: AudioBuffer + ?Sized> DerefMut for BufferRef<'a, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.inner
    }
}

impl<'a, T: AudioBuffer + ?Sized> AudioBuffer for BufferRef<'a, T> {
    fn num_channels(&self) -> usize {
        self.inner.num_channels()
    }
    
    fn num_samples(&self) -> usize {
        self.inner.num_samples()
    }
    
    fn sample_rate(&self) -> u32 {
        self.inner.sample_rate()
    }
    
    fn channel(&self, channel: usize) -> &[f32] {
        self.inner.channel(channel)
    }
    
    fn channel_mut(&mut self, channel: usize) -> &mut [f32] {
        self.inner.channel_mut(channel)
    }
}
