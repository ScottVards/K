//! Audio format definitions and conversions

use std::fmt;

/// Represents the sample format of audio data
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SampleFormat {
    /// 16-bit signed integer
    I16,
    /// 32-bit signed integer
    I32,
    /// 32-bit floating point
    F32,
    /// 64-bit floating point
    F64,
}

impl SampleFormat {
    /// Returns the size in bytes of a single sample in this format
    pub fn sample_size(&self) -> usize {
        match self {
            SampleFormat::I16 => 2,
            SampleFormat::I32 => 4,
            SampleFormat::F32 => 4,
            SampleFormat::F64 => 8,
        }
    }
    
    /// Returns true if this is a floating-point format
    pub fn is_float(&self) -> bool {
        matches!(self, SampleFormat::F32 | SampleFormat::F64)
    }
    
    /// Returns true if this is an integer format
    pub fn is_integer(&self) -> bool {
        !self.is_float()
    }
}

impl Default for SampleFormat {
    fn default() -> Self {
        SampleFormat::F32
    }
}

/// Represents the configuration of an audio stream
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AudioFormat {
    /// Sample rate in Hz
    pub sample_rate: u32,
    /// Number of channels
    pub channels: u16,
    /// Sample format
    pub format: SampleFormat,
}

impl Default for AudioFormat {
    fn default() -> Self {
        Self {
            sample_rate: 44100,
            channels: 2,
            format: SampleFormat::F32,
        }
    }
}

impl fmt::Display for AudioFormat {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let format_str = match self.format {
            SampleFormat::I16 => "16-bit int",
            SampleFormat::I32 => "32-bit int",
            SampleFormat::F32 => "32-bit float",
            SampleFormat::F64 => "64-bit float",
        };
        
        write!(
            f,
            "{} Hz, {} channel(s), {}",
            self.sample_rate, self.channels, format_str
        )
    }
}

/// Represents the configuration of an audio device
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AudioDeviceConfig {
    /// Input format (if any)
    pub input_format: Option<AudioFormat>,
    /// Output format (if any)
    pub output_format: Option<AudioFormat>,
    /// Buffer size in samples
    pub buffer_size: u32,
}

impl Default for AudioDeviceConfig {
    fn default() -> Self {
        let default_format = AudioFormat::default();
        Self {
            input_format: Some(default_format.clone()),
            output_format: Some(default_format),
            buffer_size: 1024,
        }
    }
}

/// Represents the direction of an audio stream
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Direction {
    /// Input (capture) stream
    Input,
    /// Output (playback) stream
    Output,
    /// Duplex (input and output) stream
    Duplex,
}

/// Represents the status of an audio stream
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StreamStatus {
    /// The stream is running
    Running,
    /// The stream is paused
    Paused,
    /// The stream is stopped
    Stopped,
    /// The stream encountered an error
    Error,
}

/// A timestamp for audio samples with both sample position and system time
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SampleTimestamp {
    /// Sample position
    pub position: u64,
    /// System time in nanoseconds since Unix epoch
    pub system_time: u64,
}

impl SampleTimestamp {
    /// Creates a new timestamp with the current system time
    pub fn now(position: u64) -> Self {
        Self {
            position,
            system_time: std::time::UNIX_EPOCH
                .elapsed()
                .unwrap_or_default()
                .as_nanos() as u64,
        }
    }
}
