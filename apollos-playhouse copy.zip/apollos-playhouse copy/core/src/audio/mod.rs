//! Audio processing and device management

mod buffer;
mod device;
mod format;
mod stream;

pub use buffer::*;
pub use device::*;
pub use format::*;
pub use stream::*;

/// Audio processing traits and utilities
pub mod dsp {
    pub use crate::buffer::AudioBuffer;
    pub use crate::format::AudioFormat;
    
    /// Trait for audio processors that can process audio in-place
    pub trait AudioProcessor: Send + Sync {
        /// Process a block of audio samples in-place
        fn process(&mut self, buffer: &mut dyn AudioBuffer) -> crate::Result<()>;
        
        /// Reset the processor's internal state
        fn reset(&mut self) {}
    }
    
    /// A no-op audio processor that passes through audio unchanged
    #[derive(Default)]
    pub struct PassThrough;
    
    impl AudioProcessor for PassThrough {
        fn process(&mut self, _buffer: &mut dyn AudioBuffer) -> crate::Result<()> {
            Ok(())
        }
    }
}
