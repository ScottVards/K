use serde::{Deserialize, Serialize};

use crate::time::SampleTime;

/// Commands posted to the audio thread.
///
/// Keep variants compact and copy-friendly to minimise overhead when pushing
/// through lock-free queues or shared buffers.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RtCommand {
    StartCue {
        cue_id: String,
        start_sample: SampleTime,
    },
    StopCue {
        cue_id: String,
    },
    SetParameter {
        param_id: String,
        value: f32,
    },
    ApplyAutomation {
        param_id: String,
        value: f32,
    },
    Flush,
}

impl RtCommand {
    /// Returns true if the command is purely control-plane and does not affect
    /// DSP state.
    pub fn is_control(&self) -> bool {
        matches!(self, RtCommand::Flush)
    }
}
