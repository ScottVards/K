use std::f32::consts::TAU;
use std::sync::{
    atomic::{AtomicU64, Ordering},
    Arc,
    Weak,
};

use anyhow::Context;
use cpal::{traits::{DeviceTrait, HostTrait, StreamTrait}, SampleFormat, Stream};
use arrayvec::ArrayVec;
use parking_lot::Mutex;

use crate::{
    audio::device::DeviceEventListener,
    engine::{
        scheduler::{self, AudioCommandBuffer, RenderQuantum, SchedulerConfig, SchedulerRuntime},
        RtCommand,
    },
    cue::{CueId, CueRegistry, CueStateMachine},
    error::{Error, Result},
    time::SampleTime,
};

const MAX_ACTIVE_CUES: usize = 64;
const MAX_PENDING_EVENTS: usize = 128;
const MAX_DEFERRED_STARTS: usize = 128;

/// Configuration options for the [`AudioEngine`].
#[derive(Debug, Clone)]
pub struct AudioEngineConfig {
    /// Desired sample rate. If `None`, the device default is used.
    pub sample_rate: Option<u32>,
    /// Desired block size (frames). If `None`, device default is used.
    pub block_size: Option<u32>,
    /// Capacity of the scheduler → audio command ringbuffer.
    pub ring_capacity: usize,
    /// Capacity of the control channel (UI → scheduler).
    pub control_capacity: usize,
}

impl Default for AudioEngineConfig {
    fn default() -> Self {
        Self {
            sample_rate: Some(48_000),
            block_size: Some(256),
            ring_capacity: 4096,
            control_capacity: 1024,
        }
    }
}

/// Handle returned to control threads. Provides access to the scheduler control
/// channel and exposes runtime metadata such as sample rate and block size.
#[derive(Clone)]
pub struct AudioEngineHandle {
    control_tx: crossbeam_channel::Sender<RtCommand>,
    sample_rate: u32,
    block_size: usize,
    cue_registry: Arc<CueRegistry>,
}

impl AudioEngineHandle {
    /// Send a real-time command to the scheduler.
    pub fn send(&self, cmd: RtCommand) -> Result<()> {
        self.control_tx
            .send(cmd)
            .map_err(|err| Error::Other(format!("scheduler control channel closed: {err}")))
    }

    pub fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    pub fn block_size(&self) -> usize {
        self.block_size
    }

    pub fn cue_registry(&self) -> Arc<CueRegistry> {
        self.cue_registry.clone()
    }
}

/// Core audio engine responsible for wiring together the scheduler and the
/// hardware device stream.
pub struct AudioEngine {
    scheduler: Option<SchedulerRuntime>,
    control_tx: crossbeam_channel::Sender<RtCommand>,
    command_buffer: Arc<Mutex<AudioCommandBuffer>>,
    current_sample: Arc<AtomicU64>,
    stream: Stream,
    sample_rate: u32,
    block_size: usize,
    metrics: EngineMetrics,
    cue_registry: Arc<CueRegistry>,
    audio_state: Arc<Mutex<AudioThreadState>>,
}

impl AudioEngine {
    /// Bootstraps the audio engine and starts the device stream. On success the
    /// engine is returned in the running state.
    pub fn run(config: AudioEngineConfig) -> Result<(Self, AudioEngineHandle)> {
        let host = cpal::default_host();
        let device = host
            .default_output_device()
            .ok_or_else(|| Error::AudioDevice("No default output device".into()))?;

        let mut supported_config = device
            .default_output_config()
            .context("failed to query default output config")?;

        let sample_format = supported_config.sample_format();
        let mut stream_config: cpal::StreamConfig = supported_config.clone().into();

        if let Some(rate) = config.sample_rate {
            stream_config.sample_rate = cpal::SampleRate(rate);
        }

        if let Some(block) = config.block_size {
            stream_config.buffer_size = cpal::BufferSize::Fixed(block);
        }

        let sample_rate = stream_config.sample_rate.0;
        let block_size = match stream_config.buffer_size {
            cpal::BufferSize::Fixed(size) => size as usize,
            _ => supported_config.buffer_size().min().unwrap_or(256) as usize,
        };

        let scheduler_config = SchedulerConfig {
            ring_capacity: config.ring_capacity,
            control_capacity: config.control_capacity,
            sample_rate,
            block_size,
        };

        let (scheduler_runtime, audio_buffer) = scheduler::start_scheduler(scheduler_config);
        let control_tx = scheduler_runtime.control_sender();

        let dropped_counter = audio_buffer.dropped_counter();
        let command_buffer = Arc::new(Mutex::new(audio_buffer));
        let current_sample = Arc::new(AtomicU64::new(0));
        let device_listener: Option<Arc<dyn DeviceEventListener>> = None;
        let cue_registry = Arc::new(CueRegistry::new());
        let audio_state = Arc::new(Mutex::new(AudioThreadState::new()));

        let stream = build_stream(
            &device,
            sample_format,
            stream_config.clone(),
            command_buffer.clone(),
            current_sample.clone(),
            sample_rate,
            block_size,
            stream_config.channels as usize,
            cue_registry.clone(),
            audio_state.clone(),
            device_listener.clone(),
        )?;

        stream.play().context("failed to start audio stream")?;

        let engine = Self {
            scheduler: Some(scheduler_runtime),
            control_tx: control_tx.clone(),
            command_buffer,
            current_sample,
            stream,
            sample_rate,
            block_size,
            metrics: EngineMetrics::new(dropped_counter),
            cue_registry: cue_registry.clone(),
            audio_state,
        };

        let handle = AudioEngineHandle {
            control_tx,
            sample_rate,
            block_size,
            cue_registry,
        };

        Ok((engine, handle))
    }

    pub fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    pub fn block_size(&self) -> usize {
        self.block_size
    }
}

impl Drop for AudioEngine {
    fn drop(&mut self) {
        if let Some(scheduler) = self.scheduler.take() {
            if let Err(err) = scheduler.join() {
                log::warn!("scheduler thread join failed: {err:?}");
            }
        }
    }
}

#[derive(Clone)]
pub struct EngineMetrics {
    dropped_commands: Arc<AtomicU64>,
}

impl EngineMetrics {
    fn new(counter: Arc<AtomicU64>) -> Self {
        Self {
            dropped_commands: counter,
        }
    }

    pub fn dropped_commands(&self) -> u64 {
        self.dropped_commands.load(Ordering::Relaxed)
    }

    pub fn counter(&self) -> Arc<AtomicU64> {
        Arc::clone(&self.dropped_commands)
    }
}

fn build_stream(
    device: &cpal::Device,
    sample_format: SampleFormat,
    stream_config: cpal::StreamConfig,
    command_buffer: Arc<Mutex<AudioCommandBuffer>>,
    current_sample: Arc<AtomicU64>,
    sample_rate: u32,
    block_size: usize,
    channels: usize,
    cue_registry: Arc<CueRegistry>,
    audio_state: Arc<Mutex<AudioThreadState>>,
    device_listener: Option<Arc<dyn DeviceEventListener>>,
) -> Result<Stream> {
    match sample_format {
        SampleFormat::F32 => build_output_stream::<f32>(
            device,
            stream_config,
            command_buffer,
            current_sample,
            sample_rate,
            block_size,
            channels,
            cue_registry.clone(),
            audio_state.clone(),
            device_listener,
        ),
        SampleFormat::I16 => build_output_stream::<i16>(
            device,
            stream_config,
            command_buffer,
            current_sample,
            sample_rate,
            block_size,
            channels,
            cue_registry.clone(),
            audio_state.clone(),
            device_listener,
        ),
        SampleFormat::U16 => build_output_stream::<u16>(
            device,
            stream_config,
            command_buffer,
            current_sample,
            sample_rate,
            block_size,
            channels,
            cue_registry,
            audio_state,
            device_listener,
        ),
        other => Err(Error::AudioDevice(format!("Unsupported sample format: {other:?}"))),
    }
}

fn build_output_stream<T>(
    device: &cpal::Device,
    stream_config: cpal::StreamConfig,
    command_buffer: Arc<Mutex<AudioCommandBuffer>>,
    current_sample: Arc<AtomicU64>,
    sample_rate: u32,
    block_size: usize,
    channels: usize,
    cue_registry: Arc<CueRegistry>,
    audio_state: Arc<Mutex<AudioThreadState>>,
    device_listener: Option<Arc<dyn DeviceEventListener>>,
) -> Result<Stream>
where
    T: cpal::Sample + From<f32> + Send + 'static,
{
    let err_fn = move |err| {
        log::error!("audio stream error: {err}");
        if let Some(listener) = &device_listener {
            listener.on_status_change(crate::audio::format::StreamStatus::Error);
        }
    };

    let stream = device.build_output_stream(
        &stream_config,
        move |data: &mut [T], _info| {
            process_audio_block(
                data,
                channels,
                &command_buffer,
                &current_sample,
                sample_rate,
                block_size,
                &cue_registry,
                &audio_state,
            );
        },
        err_fn,
        None,
    )?;

    Ok(stream)
}

fn process_audio_block<T>(
    output: &mut [T],
    channels: usize,
    command_buffer: &Arc<Mutex<AudioCommandBuffer>>,
    current_sample: &Arc<AtomicU64>,
    sample_rate: u32,
    block_size: usize,
) where
    T: cpal::Sample + From<f32>,
{
    let frames = if channels == 0 { 0 } else { output.len() / channels };
    let block_frames = if frames == 0 { block_size } else { frames };

    let start_sample = current_sample.fetch_add(block_frames as u64, Ordering::AcqRel);

    let render_quantum = RenderQuantum {
        current_sample: start_sample,
        block_size: block_frames,
        sample_rate,
    };

    // Drain commands queued for this block.
    {
        let mut buffer = command_buffer.lock();
        buffer.drain_with(|cmd| handle_rt_command(cmd, &render_quantum));
    }

    // TODO: invoke DSP graph, mixdown, etc. For now emit silence.
    for sample in output.iter_mut() {
        *sample = T::from(&0.0);
    }
}

fn handle_rt_command(cmd: &RtCommand, rq: &RenderQuantum) {
    match cmd {
        RtCommand::StartCue { cue_id, start_sample } => {
            let target = normalize_sample_time(start_sample, rq.sample_rate);
            let block_end = rq.current_sample + rq.block_size as u64;

            if target <= rq.current_sample {
                log::debug!(
                    "StartCue {:?} immediate (target={} current={})",
                    cue_id, target, rq.current_sample
                );
                // TODO: trigger cue immediately at frame 0 of this block.
            } else if target < block_end {
                let offset = (target - rq.current_sample) as usize;
                log::debug!(
                    "StartCue {:?} scheduled inside block at frame offset {} (target={} current={} block_len={})",
                    cue_id,
                    offset,
                    target,
                    rq.current_sample,
                    rq.block_size,
                );
                // TODO: trigger cue at `offset` frames into current block.
            } else {
                log::warn!(
                    "StartCue {:?} target {} beyond block end {}; deferring",
                    cue_id, target, block_end
                );
                // TODO: requeue for future block.
            }
        }
        RtCommand::StopCue { cue_id } => {
            log::debug!("StopCue {:?}", cue_id);
        }
        RtCommand::SetParameter { param_id, value } => {
            log::debug!("SetParameter {:?} -> {value}", param_id);
        }
        RtCommand::ApplyAutomation { param_id, value } => {
            log::trace!("ApplyAutomation {:?} -> {value}", param_id);
        }
        RtCommand::Flush => {
            log::trace!("Flush commands");
        }
    }
}

fn normalize_sample_time(sample: &SampleTime, target_rate: u32) -> u64 {
    if sample.sample_rate == target_rate {
        sample.position
    } else {
        let ratio = target_rate as f64 / sample.sample_rate as f64;
        (sample.position as f64 * ratio).round() as u64
    }
}
