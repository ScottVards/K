//! Real-time engine primitives: scheduler, clock, and RT command path.

mod audio_engine;
pub mod clock;
pub mod rt_command;
pub mod scheduler;

pub use audio_engine::{AudioEngine, AudioEngineConfig, AudioEngineHandle};
pub use clock::ClockSource;
pub use rt_command::RtCommand;
pub use scheduler::{
    start_scheduler,
    AudioCommandBuffer,
    RenderQuantum,
    SchedulerConfig,
    SchedulerRuntime,
};
