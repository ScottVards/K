use std::sync::{atomic::{AtomicU64, Ordering}, Arc};
use std::thread::{self, JoinHandle};

use arrayvec::ArrayVec;
use crossbeam_channel::{self, Receiver, Sender};
use ringbuf::{HeapRb, Producer};

use crate::engine::clock::ClockSource;
use crate::engine::rt_command::RtCommand;

/// Maximum number of commands staged per audio callback. Excess commands are
/// dropped to preserve real-time guarantees.
const AUDIO_COMMAND_SCRATCH: usize = 64;

/// Render quantum metadata passed to the audio callback each block.
#[derive(Debug, Clone, Copy)]
pub struct RenderQuantum {
    /// Absolute sample index of the start of the current block.
    pub current_sample: u64,
    /// Number of samples in the current audio block.
    pub block_size: usize,
    /// Active sample rate in Hertz.
    pub sample_rate: u32,
}

/// Configuration used when bootstrapping the scheduler.
#[derive(Debug, Clone)]
pub struct SchedulerConfig {
    /// Capacity of the real-time ringbuffer (scheduler → audio thread).
    pub ring_capacity: usize,
    /// Capacity of the control-channel queue (control threads → scheduler).
    pub control_capacity: usize,
    /// Audio sample rate used for timeline calculations.
    pub sample_rate: u32,
    /// Audio block size in samples.
    pub block_size: usize,
}

impl Default for SchedulerConfig {
    fn default() -> Self {
        Self {
            ring_capacity: 4096,
            control_capacity: 1024,
            sample_rate: 48_000,
            block_size: 256,
        }
    }
}

/// Audio-thread-safe command buffer. The audio callback owns this structure and
/// drains pending commands each render quantum without allocating.
pub struct AudioCommandBuffer {
    consumer: ringbuf::Consumer<RtCommand>,
    scratch: ArrayVec<RtCommand, AUDIO_COMMAND_SCRATCH>,
    dropped: Arc<AtomicU64>,
}

impl AudioCommandBuffer {
    /// Create a new buffer from the ringbuffer consumer side.
    pub fn new(consumer: ringbuf::Consumer<RtCommand>) -> Self {
        Self {
            consumer,
            scratch: ArrayVec::new(),
            dropped: Arc::new(AtomicU64::new(0)),
        }
    }

    /// Drain all currently pending commands and invoke `callback` for each one
    /// without allocating.
    pub fn drain_with<F>(&mut self, mut callback: F)
    where
        F: FnMut(&RtCommand),
    {
        self.scratch.clear();
        while let Some(cmd) = self.consumer.pop() {
            if self.scratch.try_push(cmd).is_err() {
                self.dropped.fetch_add(1, Ordering::Relaxed);
                log::warn!("audio scratch buffer saturated; dropping RT commands");
                break;
            }
        }

        for cmd in &self.scratch {
            callback(cmd);
        }
    }

    /// Returns the number of commands dropped because the scratch buffer was
    /// saturated.
    pub fn dropped_commands(&self) -> u64 {
        self.dropped.load(Ordering::Relaxed)
    }

    /// Returns an atomically updated counter that observers can share.
    pub fn dropped_counter(&self) -> Arc<AtomicU64> {
        Arc::clone(&self.dropped)
    }
}

/// Runtime handles for the scheduler subsystem.
pub struct SchedulerRuntime {
    control_tx: Sender<RtCommand>,
    thread: JoinHandle<()>,
}

impl SchedulerRuntime {
    /// Obtain a sender that can be used by control threads to enqueue commands.
    pub fn control_sender(&self) -> Sender<RtCommand> {
        self.control_tx.clone()
    }

    /// Block until the scheduler thread exits.
    pub fn join(self) -> thread::Result<()> {
        let SchedulerRuntime { control_tx, thread } = self;
        drop(control_tx);
        thread.join()
    }
}

/// Start the scheduler subsystem.
///
/// Returns both the runtime handles (for control threads) and the audio command
/// buffer that must be owned by the audio thread.
pub fn start_scheduler(config: SchedulerConfig) -> (SchedulerRuntime, AudioCommandBuffer) {
    let (control_tx, control_rx) = crossbeam_channel::bounded::<RtCommand>(config.control_capacity);

    let ring = HeapRb::<RtCommand>::new(config.ring_capacity);
    let (producer, consumer) = ring.split();

    let clock = ClockSource::new(config.sample_rate, config.block_size);
    let scheduler = SchedulerThread::new(control_rx, producer, clock);

    let thread = thread::Builder::new()
        .name("apollo-scheduler".into())
        .spawn(move || scheduler.run())
        .expect("failed to spawn scheduler thread");

    let runtime = SchedulerRuntime { control_tx, thread };
    let audio_buffer = AudioCommandBuffer::new(consumer);

    (runtime, audio_buffer)
}

/// Internal scheduler thread state.
struct SchedulerThread {
    control_rx: Receiver<RtCommand>,
    producer: Producer<RtCommand>,
    clock: ClockSource,
}

impl SchedulerThread {
    fn new(control_rx: Receiver<RtCommand>, producer: Producer<RtCommand>, clock: ClockSource) -> Self {
        Self {
            control_rx,
            producer,
            clock,
        }
    }

    fn run(mut self) {
        log::info!("Scheduler thread started");
        while let Ok(cmd) = self.control_rx.recv() {
            if let Err(cmd) = self.producer.push(cmd) {
                log::error!("RT ringbuffer full; dropping command: {:?}", cmd);
            }
        }
        log::info!("Scheduler thread exiting");
    }
}
