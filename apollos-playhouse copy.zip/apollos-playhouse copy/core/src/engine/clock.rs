use std::time::{Duration, Instant};

/// High-resolution clock used by the scheduler to map wall-clock instants to
/// audio sample positions. The clock anchors an `Instant` to a specific sample
/// index and exposes conversion helpers for sample-accurate timing.
#[derive(Debug)]
pub struct ClockSource {
    sample_rate: u32,
    block_size: usize,
    anchor_time: Instant,
    anchor_sample: u64,
}

impl ClockSource {
    /// Construct a new clock anchored at the current instant and sample `0`.
    pub fn new(sample_rate: u32, block_size: usize) -> Self {
        Self {
            sample_rate,
            block_size,
            anchor_time: Instant::now(),
            anchor_sample: 0,
        }
    }

    /// Returns the configured sample rate.
    pub fn sample_rate(&self) -> u32 {
        self.sample_rate
    }

    /// Returns the configured block size in samples.
    pub fn block_size(&self) -> usize {
        self.block_size
    }

    /// Converts an absolute `Instant` into the corresponding sample index,
    /// clamped at the current anchor.
    pub fn instant_to_sample(&self, instant: Instant) -> u64 {
        let elapsed = instant
            .checked_duration_since(self.anchor_time)
            .unwrap_or_default();
        let samples = (elapsed.as_secs_f64() * self.sample_rate as f64).round();
        if samples.is_sign_negative() {
            self.anchor_sample
        } else {
            self.anchor_sample.saturating_add(samples as u64)
        }
    }

    /// Convenience helper returning the current sample index for `Instant::now()`.
    pub fn now_sample(&self) -> u64 {
        self.instant_to_sample(Instant::now())
    }

    /// Converts a sample index back into an `Instant` relative to the anchor.
    pub fn sample_to_instant(&self, sample: u64) -> Instant {
        let delta_samples = sample.saturating_sub(self.anchor_sample) as f64;
        let secs = delta_samples / self.sample_rate as f64;
        self.anchor_time + Duration::from_secs_f64(secs)
    }

    /// Advances the anchor by `advance_samples`, re-basing both sample and
    /// time anchors. This should be invoked periodically from the audio thread
    /// to keep the scheduler clock aligned with the hardware callback cadence.
    pub fn advance_anchor(&mut self, advance_samples: u64) {
        self.anchor_sample = self.anchor_sample.saturating_add(advance_samples);
        self.anchor_time = Instant::now();
    }
}
