//! Error types for the Apollo Core library

use std::{error, fmt, io, string::FromUtf8Error};
use thiserror::Error;

/// A type alias for `Result<T, Error>`
pub type Result<T> = std::result::Result<T, Error>;

/// The error type for Apollo Core operations
#[derive(Error, Debug)]
pub enum Error {
    /// I/O error
    #[error("I/O error: {0}")]
    Io(#[from] io::Error),

    /// Audio device error
    #[error("Audio device error: {0}")]
    AudioDevice(String),

    /// Invalid audio format
    #[error("Invalid audio format: {0}")]
    InvalidFormat(String),

    /// Cue error
    #[error("Cue error: {0}")]
    Cue(String),

    /// Time error
    #[error("Time error: {0}")]
    Time(String),

    /// Other errors
    #[error("{0}")]
    Other(String),
}

impl From<&str> for Error {
    fn from(s: &str) -> Self {
        Error::Other(s.to_string())
    }
}

impl From<String> for Error {
    fn from(s: String) -> Self {
        Error::Other(s)
    }
}

impl From<FromUtf8Error> for Error {
    fn from(e: FromUtf8Error) -> Self {
        Error::Other(e.to_string())
    }
}
