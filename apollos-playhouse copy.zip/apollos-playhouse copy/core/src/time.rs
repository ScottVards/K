//! Time-related functionality for Apollo Core

use std::time::Duration;

/// Represents a time signature (e.g., 4/4, 3/4, 6/8)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TimeSignature {
    /// Number of beats per measure
    pub numerator: u8,
    /// Note value that gets one beat
    pub denominator: u8,
}

impl Default for TimeSignature {
    fn default() -> Self {
        Self {
            numerator: 4,
            denominator: 4,
        }
    }
}

/// Represents a point in musical time
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
pub struct BeatTime {
    /// Total number of beats
    pub beats: f64,
    /// Beats per minute
    pub bpm: f64,
}

impl BeatTime {
    /// Creates a new BeatTime
    pub fn new(beats: f64, bpm: f64) -> Self {
        Self { beats, bpm }
    }

    /// Converts to seconds
    pub fn to_seconds(&self) -> f64 {
        (self.beats * 60.0) / self.bpm
    }

    /// Converts to a Duration
    pub fn to_duration(&self) -> Duration {
        Duration::from_secs_f64(self.to_seconds())
    }
}

/// Represents a point in sample time
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Hash)]
pub struct SampleTime {
    /// Sample position
    pub position: u64,
    /// Sample rate in Hz
    pub sample_rate: u32,
}

impl SampleTime {
    /// Creates a new SampleTime
    pub fn new(position: u64, sample_rate: u32) -> Self {
        Self {
            position,
            sample_rate,
        }
    }

    /// Converts to seconds
    pub fn to_seconds(&self) -> f64 {
        self.position as f64 / self.sample_rate as f64
    }

    /// Converts to a Duration
    pub fn to_duration(&self) -> Duration {
        Duration::from_secs_f64(self.to_seconds())
    }
}

/// A timebase for synchronization
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum TimeBase {
    /// Time in seconds
    Seconds(f64),
    /// Time in samples
    Samples(u64),
    /// Time in beats
    Beats(f64),
    /// Time in musical bars and beats (bar.beat)
    BarsAndBeats(u32, f64),
}

impl TimeBase {
    /// Converts to seconds
    pub fn to_seconds(&self, bpm: f64, sample_rate: u32) -> f64 {
        match self {
            TimeBase::Seconds(secs) => *secs,
            TimeBase::Samples(samples) => *samples as f64 / sample_rate as f64,
            TimeBase::Beats(beats) => (beats * 60.0) / bpm,
            TimeBase::BarsAndBeats(bars, beats) => {
                let total_beats = (*bars as f64 * 4.0) + beats; // Assuming 4/4 time
                (total_beats * 60.0) / bpm
            }
        }
    }
}
