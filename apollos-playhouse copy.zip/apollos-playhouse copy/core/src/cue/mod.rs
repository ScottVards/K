//! Cue management primitives: identifiers, state machines, and registry.

use std::collections::HashMap;
use std::fmt;
use std::sync::{Arc, Weak};
use std::sync::atomic::{AtomicU8, Ordering};

use parking_lot::RwLock;

/// Maximum number of state transitions recorded for debugging.
const _MAX_HISTORY: usize = 16;

/// Unique identifier for a cue.
#[derive(Clone, Hash, PartialEq, Eq, PartialOrd, Ord)]
pub struct CueId(Arc<str>);

impl CueId {
    /// Create a cue identifier from a string slice.
    pub fn new(id: impl AsRef<str>) -> Self {
        Self(Arc::<str>::from(id.as_ref()))
    }

    /// Returns the identifier as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Debug for CueId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CueId").field(&self.as_str()).finish()
    }
}

impl fmt::Display for CueId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

impl From<String> for CueId {
    fn from(value: String) -> Self {
        CueId::new(value)
    }
}

impl From<&str> for CueId {
    fn from(value: &str) -> Self {
        CueId::new(value)
    }
}

/// Public API oriented around high-level cue states.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CueState {
    Ready = 0,
    Running = 1,
    Stopping = 2,
    Completed = 3,
    Error = 4,
}

impl CueState {
    fn from_u8(value: u8) -> Self {
        match value {
            0 => CueState::Ready,
            1 => CueState::Running,
            2 => CueState::Stopping,
            3 => CueState::Completed,
            _ => CueState::Error,
        }
    }
}

/// Thread-safe state machine for a cue. The audio thread owns the definitive
/// state; other threads interact via atomic transitions.
pub struct CueStateMachine {
    state: AtomicU8,
}

impl CueStateMachine {
    pub fn new() -> Self {
        Self {
            state: AtomicU8::new(CueState::Ready as u8),
        }
    }

    /// Returns the current cue state.
    pub fn state(&self) -> CueState {
        CueState::from_u8(self.state.load(Ordering::Acquire))
    }

    /// Attempt to move the cue into the running state.
    pub fn request_start(&self) -> bool {
        self.state
            .compare_exchange(
                CueState::Ready as u8,
                CueState::Running as u8,
                Ordering::AcqRel,
                Ordering::Relaxed,
            )
            .is_ok()
            || self
                .state
                .compare_exchange(
                    CueState::Completed as u8,
                    CueState::Running as u8,
                    Ordering::AcqRel,
                    Ordering::Relaxed,
                )
                .is_ok()
    }

    /// Mark the cue as running (used by audio thread when the start actually
    /// takes place).
    pub fn mark_running(&self) {
        self.state.store(CueState::Running as u8, Ordering::Release);
    }

    /// Request a stop. Returns true if the cue was running.
    pub fn request_stop(&self) -> bool {
        self.state
            .compare_exchange(
                CueState::Running as u8,
                CueState::Stopping as u8,
                Ordering::AcqRel,
                Ordering::Relaxed,
            )
            .is_ok()
    }

    /// Mark the cue as completed (typically when playback ends or after
    /// handling a stop request).
    pub fn mark_completed(&self) {
        self.state
            .store(CueState::Completed as u8, Ordering::Release);
    }
}

/// Registry holding cue state machines accessible from any thread.
pub struct CueRegistry {
    entries: RwLock<HashMap<CueId, Arc<CueStateMachine>>>,
}

impl CueRegistry {
    pub fn new() -> Self {
        Self {
            entries: RwLock::new(HashMap::new()),
        }
    }

    /// Obtain the state machine for a cue, inserting if necessary.
    pub fn get_or_insert(&self, cue_id: CueId) -> Arc<CueStateMachine> {
        if let Some(existing) = self.entries.read().get(&cue_id).cloned() {
            return existing;
        }

        let mut write = self.entries.write();
        write
            .entry(cue_id.clone())
            .or_insert_with(|| Arc::new(CueStateMachine::new()))
            .clone()
    }

    /// Downgrade to a weak pointer for long-lived audio-thread handles to avoid
    /// retaining stale cues indefinitely.
    pub fn get_weak(&self, cue_id: &CueId) -> Option<Weak<CueStateMachine>> {
        self.entries
            .read()
            .get(cue_id)
            .map(|arc| Arc::downgrade(arc))
    }
}
