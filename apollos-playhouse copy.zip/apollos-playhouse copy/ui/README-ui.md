# Apollo UI Scaffold

This crate hosts the Qt Quick / QML user interface for Apollo's Playhouse.

## Prerequisites

- Qt 6 with Qt Quick and Qt Quick Controls modules installed.
- Rust toolchain (1.70+ recommended).

## Building

```bash
cargo build -p apollo-ui
```

## Running the scaffold

```bash
cargo run -p apollo-ui
```

The application launches a placeholder layout that mirrors the Phase 1 wireframe: cue list, inspector, automation dock, and spatial/measurement panels, all populated with dummy data.

## Project structure

```
ui/
  qml/
    components/     # Reusable UI primitives and panels
    views/           # Top-level application views (MainWindow)
    themes/          # Palette, typography, spacing tokens
  src/
    cue_model.rs     # QAbstractListModel exposing cues to QML
    transport_state.rs
    main.rs          # Application entry point
  assets/
    icons/
    fonts/
    color_tokens/
  Cargo.toml
  build.rs
```

## Next steps

- Flesh out component logic in `qml/components/*`.
- Bind automation curves and spatial data once the backend provides live signals.
- Extend `transport_state.rs` with real transport metrics.
- Add UI tests (squish) and linting (qmlfmt) to CI.
