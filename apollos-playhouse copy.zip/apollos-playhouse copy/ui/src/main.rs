use qmetaobject::prelude::*;
use qmetaobject::QUrl;

mod cue_model;
mod transport_state;

fn main() {
    qmetaobject::init_qt_resources();

    let cue_model = cue_model::CueModel::new_dummy();
    let transport_state = transport_state::TransportState::new_dummy();

    let mut engine = QmlEngine::new();

    engine
        .root_context()
        .set_context_property("cueModel".into(), cue_model.into_qobject());
    engine
        .root_context()
        .set_context_property("transportState".into(), transport_state.into_qobject());

    let qml_path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("qml/views/MainWindow.qml");
    engine.load_file(QUrl::from_local_file(qml_path));

    if let Err(err) = engine.exec() {
        eprintln!("Failed to start QML engine: {err}");
    }
}
