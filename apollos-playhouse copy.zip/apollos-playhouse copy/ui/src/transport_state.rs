use std::cell::{Cell, RefCell};

use qmetaobject::prelude::*;

#[derive(QObject)]
pub struct TransportState {
    base: qt_base_class!(trait QObject),
    #[qt_property(QString)]
    current_timecode: RefCell<QString>,
    #[qt_property(QString)]
    next_cue: RefCell<QString>,
    #[qt_property(f32)]
    latency_ms: Cell<f32>,
}

impl TransportState {
    pub fn new_dummy() -> QObjectBox<Self> {
        QObjectBox::new(Self {
            base: Default::default(),
            current_timecode: RefCell::new(QString::from("00:00:00.000")),
            next_cue: RefCell::new(QString::from("House Lights")),
            latency_ms: Cell::new(1.6),
        })
    }
}
