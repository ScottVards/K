use std::cell::RefCell;
use std::collections::HashMap;

use qmetaobject::prelude::*;

const ROLE_ID: i32 = Qt::UserRole as i32 + 1;
const ROLE_NAME: i32 = Qt::UserRole as i32 + 2;
const ROLE_STATUS: i32 = Qt::UserRole as i32 + 3;

#[derive(Clone)]
struct CueEntry {
    id: QString,
    name: QString,
    status: QString,
}

#[derive(QObject)]
pub struct CueModel {
    base: qt_base_class!(trait QAbstractListModel),
    cues: RefCell<Vec<CueEntry>>,
}

impl CueModel {
    pub fn new_dummy() -> QObjectBox<Self> {
        let cues = vec![
            CueEntry {
                id: QString::from("001"),
                name: QString::from("Intro Music"),
                status: QString::from("Ready"),
            },
            CueEntry {
                id: QString::from("002"),
                name: QString::from("House Lights"),
                status: QString::from("Armed"),
            },
            CueEntry {
                id: QString::from("003"),
                name: QString::from("Voiceover"),
                status: QString::from("Pending"),
            },
            CueEntry {
                id: QString::from("004"),
                name: QString::from("Scene Transition"),
                status: QString::from("Ready"),
            },
        ];

        QObjectBox::new(Self {
            base: Default::default(),
            cues: RefCell::new(cues),
        })
    }
}

impl QAbstractListModel for CueModel {
    fn row_count(&self) -> i32 {
        self.cues.borrow().len() as i32
    }

    fn data(&self, index: QModelIndex, role: i32) -> QVariant {
        let cues = self.cues.borrow();
        let row = index.row() as usize;
        if row >= cues.len() {
            return QVariant::default();
        }
        let cue = &cues[row];
        match role {
            ROLE_ID => cue.id.clone().into(),
            ROLE_NAME => cue.name.clone().into(),
            ROLE_STATUS => cue.status.clone().into(),
            _ => QVariant::default(),
        }
    }

    fn role_names(&self) -> HashMap<i32, QByteArray> {
        HashMap::from([
            (ROLE_ID, QByteArray::from("cueId")),
            (ROLE_NAME, QByteArray::from("cueName")),
            (ROLE_STATUS, QByteArray::from("cueStatus")),
        ])
    }
}
