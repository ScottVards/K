fn main() {
    println!("cargo:rerun-if-changed=qml");
    println!("cargo:rerun-if-changed=assets");
}
